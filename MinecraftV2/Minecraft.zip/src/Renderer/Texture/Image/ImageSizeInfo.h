#pragma once

struct ImageSizeInfo
{
	int width;
	int height;
	int bpp;
};