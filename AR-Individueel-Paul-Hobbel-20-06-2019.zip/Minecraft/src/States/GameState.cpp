#include "GameState.h"

GameState::GameState(Game& game): mGame(&game)
{
}

void GameState::onOpen()
{
}
